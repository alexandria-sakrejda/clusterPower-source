#' This help page is a stub. Equations do not yet exist for this type of analysis and outcome.
#' Try \code{cps.did.count()} instead.
#' 
#' @author Alexandria C. Sakrejda (\email{acbro0@@umass.edu}
#' @author Ken Kleinman (\email{ken.kleinman@@gmail.com})
#' 
#' @param ... Any argument passed to the function.
#' 
#' @return A helpful suggestion to use cps.did.count() instead.
#' 
#' @export
cpa.did.count <- function(...) {
  return("No method exists for cpa.did.count. Use cps.did.count() instead.")
}
