## needs to return just a p-value from the permutation method

#make.permutation.inference <- function(){}
