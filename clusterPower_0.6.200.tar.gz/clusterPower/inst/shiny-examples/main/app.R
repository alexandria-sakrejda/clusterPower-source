#
# This is a Shiny web application. You can run the application by clicking
# the 'Run App' button above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(clusterPower)
library(shinythemes)
library(shiny)
library(shinyBS)
library(promises)
library(future)
library(future.callr)
library(shinyjs)
library(V8)
library(ggplot2)

plan(callr)

# labels for arguments

analyticnsubjectstext <- "Mean observations per cluster (nsubjects)"
analyticnclusterstext <- "Mean clusters per arm (nclusters)"
analyticICCtext <- "Intracluster correlation coefficient (ICC)"

analyticsigma_sqtext <- "Within-cluster variance (sigma_sq)"
analyticsigma_b_sqtext <- "Between-cluster variance (sigma_b_sq)"
refsigma_sqtext <-
  "Reference arm within-cluster variance (sigma_sq)"
treatsigma_sqtext <-
  "Treatment arm within-cluster variance (sigma_sq)"
refsigma_b_sqtext <-
  "Reference arm between-cluster variance (sigma_b_sq)"
treatsigma_b_sqtext <-
  "Treatment arm between-cluster variance (sigma_b_sq)"
simnsimtext <- "Number of simulations (nsim)"
simnsubjectstext <- "Observations per cluster (nsubjects)"
simnclusterstext <- "Clusters per arm (nclusters)"
refmutext <- "Reference arm expected mean (mu)"
treatmutext <- "Treatment arm expected mean (mu2)"
refICCtext <- "Reference arm ICC (ICC)"
treatICCtext <- "Treatment arm ICC (ICC)"

# returns the vignette for the help section link
get_vignette_link <- function(...) {
  x <- vignette(...)
  
  if (nzchar(out <- x$PDF)) {
    ext <- tools::file_ext(out)
    port <- if (tolower(ext) == "html")
      tools::startDynamicHelp(NA)
    else
      0L
    if (port > 0L) {
      out <- sprintf("http://127.0.0.1:%d/library/%s/doc/%s",
                     port,
                     basename(x$Dir),
                     out)
      return(out)
    }
  }
  stop("no html help found")
}


ui <- fluidPage(
  theme = shinytheme("united"),
  h1(
    id = "big-heading",
    "Power Estimation for Randomized Controlled Trials: clusterPower"
  ),
  tags$style(HTML("#big-heading{color: #337ab7;}")),
  shinyjs::useShinyjs(),
  sidebarLayout(
    sidebarPanel(
      selectInput(
        "type",
        "CRT Type",
        choices = c(
          "Parallel",
          "Multi-Arm",
          "Difference-in-Difference",
          "Stepped Wedge",
          "Individually-Randomized Group"
        )
      ),
      selectInput(
        "dist",
        "Outcome Distribution",
        choices = c("Normal", "Binary", "Count")
      ),
      selectInput("meth", "Method",
                  choices = c("Analytic", "Simulation")),
      # Below values can be reset to defaults using the restore defaults button
      div(
        id = "allValues",
        shinyjs::hidden(numericInput("power", "power", value = NA)),
        
        #input for cpa.normal  -------------------------------------------------------------
        conditionalPanel(
          "input.type == 'Parallel' && input.dist == 'Normal' && input.meth == 'Analytic'",
          
          # nclusters
          numericInput("nclusterscpanormal", analyticnclusterstext, value = 10),
          
          #nsubjects
          numericInput("nsubjectscpanormal",
                       analyticnsubjectstext,
                       value = 20),
          
          # CV
          numericInput("CVcpanormal", "Coefficient of variation (CV)", value = 0),
          bsTooltip(
            "CVcpanormal",
            "When CV equals 0, all clusters are the same size.",
            'right',
            options = list(container = "body")
          ),
          
          # d
          numericInput("dcpanormal", "Expected difference in arm means (d)", value = 0.43),
          
          # ICC
          numericInput(
            "ICCcpanormal",
            analyticICCtext,
            value = NA,
            step = 0.01,
            min = 0,
            max = 1
          ),
          
          # variance params
          numericInput(
            "sigma_sqcpanormal",
            analyticsigma_sqtext,
            value = 0.01,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sqcpanormal",
            analyticsigma_b_sqtext,
            step = 0.001,
            value = 0.1,
            min = 0
          ),
          numericInput("vartcpanormal", "Total variation of the outcome (vart)", value = NA)
        ),
        
        # input for cps.normal
        conditionalPanel(
          "input.type == 'Parallel' && input.dist == 'Normal' && input.meth == 'Simulation'",
          
          # nsim
          numericInput(
            "nsimcpsnormal",
            simnsimtext,
            value = 100,
            max = 500000,
            min = 0
          ),
          
          # nclusters
          textInput("nclusterscpsnormal",
                    simnclusterstext,
                    value = "10, 10"),
          bsTooltip(
            "nclusterscpsmanormal",
            "Note: comma delimited",
            'right',
            options = list(container = "body")
          ),
          
          # nsubjects
          textInput("nsubjectscpsnormal",
                    simnsubjectstext,
                    value = "20, 20"),
          bsTooltip(
            "nsubjectscpsmanormal",
            "Note: comma delimited",
            'right',
            options = list(container = "body")
          ),
          
          ## REFERENCE VALUES
          # mu
          numericInput("mucpsnormal", "Reference arm expected mean (mu)", value = 2.4),
          
          # variance params
          numericInput(
            "ICCcpsnormal",
            "Reference arm ICC (ICC)",
            value = NA,
            step = 0.01,
            min = 0,
            max = 1
          ),
          bsTooltip(
            "ICCcpsmanormal",
            "Intracluster correlation coefficient",
            'right',
            options = list(container = "body")
          ),
          
          numericInput(
            "sigma_sqcpsnormal",
            refsigma_sqtext,
            value = 0.2,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sqcpsnormal",
            refsigma_b_sqtext,
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          
          ### TREATMENT ARM
          # mu
          numericInput("mu2cpsnormal", treatmutext, value = 1.5),
          
          # variance params
          numericInput(
            "ICC2cpsnormal",
            treatICCtext,
            value = NA,
            step = 0.01,
            min = 0,
            max = 1
          ),
          bsTooltip(
            "ICC2cpsmanormal",
            "Intracluster correlation coefficient",
            'right',
            options = list(container = "body")
          ),
          
          numericInput(
            "sigma_sq2cpsnormal",
            treatsigma_sqtext,
            value = 0.2,
            step = 0.001,
            min = 0
          ),
          
          numericInput(
            "sigma_b_sq2cpsnormal",
            treatsigma_b_sqtext,
            value = 0.5,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.binary inputs start
        conditionalPanel(
          "input.type == 'Parallel' && input.dist == 'Binary' && input.meth == 'Analytic'",
          numericInput("nclusterscpabinary", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpabinary",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput("CVcpabinary", "Coefficient of variation (CV)", value = 0),
          numericInput(
            "ICCcpabinary",
            "Intracluster correlation coefficient (ICC)",
            value = 0.05,
            step = 0.01,
            min = 0,
            max = 1
          ),
          numericInput(
            "p1cpabinary",
            "Outcome proportion (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "p2cpabinary",
            "Outcome proportion (Arm 2)",
            value = 0.24,
            step = 0.001,
            min = 0,
            max = 1
          ),
          checkboxInput("pooledcpabinary", "Pooled standard error", value = FALSE),
          checkboxInput("p1inccpabinary", "p1 > p2", value = FALSE),
          checkboxInput("tdistcpabinary", "Use t-distribution", value = FALSE)
        ),
        
        # cps.binary inputs start
        conditionalPanel(
          "input.type == 'Parallel' && input.dist == 'Binary' && input.meth == 'Simulation'",
          numericInput("nclusterscpsbinary", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpsbinary",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsimcpsbinary",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput(
            "p1cpsbinary",
            "Outcome proportion (Arm 1)",
            value = 0.8,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "p2cpsbinary",
            "Outcome proportion (Arm 2)",
            value = 0.5,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "sigma_b_sqcpsbinary",
            "Between-cluster variance (Arm 1)",
            value = 1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq2cpsbinary",
            "Between-cluster variance (Arm 2)",
            value = 1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.count input starts
        conditionalPanel(
          "input.type == 'Parallel' && input.dist == 'Count' && input.meth == 'Analytic'",
          numericInput("nclusterscpacount", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpacount",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "CVBcpacount",
            "Between-cluster coefficient of variation (CV)",
            value = 0.01
          ),
          numericInput("r1cpacount",  "Mean event rate (Arm 1)", value = 0.2),
          numericInput("r2cpacount",  "Mean event rate (Arm 2)", value = 0.35),
          checkboxInput(
            "r1inccpacount",
            "Intervention probability < control probability",
            value = FALSE
          )
        ),
        
        # cps.count input starts
        conditionalPanel(
          "input.type == 'Parallel' && input.dist == 'Count' && input.meth == 'Simulation'",
          numericInput("nclusterscpscount", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpscount",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsimcpscount",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput(
            "sigma_b_sqcpscount",
            "Between-cluster variance (Arm 1)",
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq2cpscount",
            "Between-cluster variance (Arm 2)",
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "c1cpscount",
            "Expected outcome count (Arm 1)",
            value = 200,
            step = 1,
            min = 0
          ),
          numericInput(
            "c2cpscount",
            "Expected outcome count (Arm 2)",
            value = 80,
            step = 1,
            min = 0
          )
        ),
        
        # cpa.ma.normal input starts
        conditionalPanel(
          "input.type == 'Multi-Arm' && input.dist == 'Normal' && input.meth == 'Analytic'",
          numericInput("nclusterscpamanormal", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpamanormal",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "narmscpamanormal",
            "Number of arms",
            value = 3,
            max = 50,
            min = 2,
            step = 1
          ),
          numericInput(
            "varacpamanormal",
            "Between-arm variance",
            value = 0.02,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "varccpamanormal",
            "Between-cluster variance",
            value = 0.01,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "varecpamanormal",
            "Within-cluster variance",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cps.ma.normal input start
        conditionalPanel(
          "input.type == 'Multi-Arm' && input.dist == 'Normal' && input.meth == 'Simulation'",
          textInput(
            "nclusterscpsmanormal",
            "Number of Clusters (comma delimited)",
            value = "10, 10, 10"
          ),
          textInput(
            "nsubjectscpsmanormal",
            "Number of Observations (per cluster, comma delimited)",
            value = "20, 20, 20"
          ),
          numericInput(
            "nsimcpsmanormal",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          
          sliderInput(
            "narmscpsmanormal",
            "Number of arms",
            value = 3,
            min = 2,
            max = 10,
            step = 1
          ),
          textInput(
            "meanscpsmanormal",
            "Expected absolute treatment effect for each arm (comma delimited)",
            "22.0, 21.0, 22.5"
          ),
          textInput(
            "ICCcpsmanormal",
            "Intracluster correlation coefficient (ICC)",
            value = NULL
          ),
          textInput(
            "sigma_sqcpsmanormal",
            "Within-cluster variance (comma delimited)",
            value = "0.1, 0.1, 0.1"
          ),
          textInput(
            "sigma_b_sqcpsmanormal",
            "Between-cluster variance (comma delimited)",
            value = "0.1, 0.1, 0.1"
          ),
          selectInput(
            "multi_p_methodcpsmanormal",
            "Multiple comparisons adjustment",
            choices = c(
              "holm",
              "hochberg",
              "hommel",
              "bonferroni",
              "BH",
              "BY",
              "fdr",
              "none"
            ),
            selected = "bonferroni",
            multiple = FALSE
          ),
          checkboxInput("tdistcpsmanormal", "Use t-distribution", value = FALSE)
        ),
        
        # cpa.ma.binary (no method)
        conditionalPanel(
          "input.type == 'Multi-Arm' && input.dist == 'Binary' && input.meth == 'Analytic'",
          HTML("No method exists. Use the simulation option instead.")
        ),
        
        # cps.ma.binary input start
        conditionalPanel(
          "input.type == 'Multi-Arm' && input.dist == 'Binary' && input.meth == 'Simulation'",
          textInput(
            "nclusterscpsmabinary",
            "Number of Clusters (comma delimited)",
            value = "10, 10, 10"
          ),
          textInput(
            "nsubjectscpsmabinary",
            "Number of Observations (per cluster, comma delimited)",
            value = "20, 20, 20"
          ),
          numericInput(
            "nsimcpsmabinary",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          sliderInput(
            "narmscpsmabinary",
            "Number of arms",
            value = 3,
            min = 2,
            max = 10,
            step = 1
          ),
          textInput(
            "probscpsmabinary",
            "Treatment effect probabilities for each arm (comma delimited)",
            "0.30, 0.4, 0.5"
          ),
          textInput(
            "sigma_b_sqcpsmabinary",
            "Between-cluster variance (comma delimited)",
            value = "0.1, 0.1, 0.1"
          ),
          selectInput(
            "multi_p_methodcpsmabinary",
            "Multiple comparisons adjustment",
            choices = c(
              "holm",
              "hochberg",
              "hommel",
              "bonferroni",
              "BH",
              "BY",
              "fdr",
              "none"
            ),
            selected = "bonferroni",
            multiple = FALSE
          ),
          checkboxInput("tdistcpsmabinary", "Use t-distribution", value = FALSE)
        ),
        
        # cpa.ma.count (no method)
        conditionalPanel(
          "input.type == 'Multi-Arm' && input.dist == 'Count' && input.meth == 'Analytic'",
          HTML("No method exists. Use the simulation option instead.")
        ),
        
        # cps.ma.count input start
        conditionalPanel(
          "input.type == 'Multi-Arm' && input.dist == 'Count' && input.meth == 'Simulation'",
          textInput(
            "nclusterscpsmacount",
            "Number of Clusters (comma delimited)",
            value = "10, 10, 10"
          ),
          textInput(
            "nsubjectscpsmacount",
            "Number of Observations (per cluster, comma delimited)",
            value = "20, 20, 20"
          ),
          numericInput(
            "nsimcpsmacount",
            "Number of simulations",
            value = 10,
            max = 500000,
            min = 0
          ),
          sliderInput(
            "narmscpsmacount",
            "Number of arms",
            value = 3,
            min = 2,
            max = 10,
            step = 1
          ),
          textInput(
            "countscpsmacount",
            "Mean event per unit time for each arm (comma delimited)",
            "30, 35, 70"
          ),
          textInput(
            "sigma_b_sqcpsmacount",
            "Between-cluster variance (comma delimited)",
            value = "1, 1.2, 1.9"
          ),
          selectInput(
            "multi_p_methodcpsmacount",
            "Multiple comparisons adjustment",
            choices = c(
              "holm",
              "hochberg",
              "hommel",
              "bonferroni",
              "BH",
              "BY",
              "fdr",
              "none"
            ),
            selected = "bonferroni",
            multiple = FALSE
          ),
          checkboxInput("tdistcpsmacount", "Use t-distribution", value = FALSE)
        ),
        
        # cpa.did.normal input start
        conditionalPanel(
          "input.type == 'Difference-in-Difference' && input.dist == 'Normal' && input.meth == 'Analytic'",
          numericInput("nclusterscpadidnormal", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpadidnormal",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput("dcpadidnormal", "Means difference", value = 1.02),
          numericInput(
            "ICCcpadidnormal",
            "Intracluster correlation coefficient (ICC)",
            value = 0.05,
            step = 0.01,
            min = 0,
            max = 1
          ),
          numericInput(
            "rho_ccpadidnormal",
            "Baseline and post-test cluster-level correlation",
            value = 0
          ),
          numericInput(
            "rho_scpadidnormal",
            "Baseline and post-test subject-level correlation",
            value = 0
          ),
          numericInput("vartcpadidnormal", "Total variation of the outcome", value = 3)
        ),
        
        # cps.did.normal input start
        conditionalPanel(
          "input.type == 'Difference-in-Difference' && input.dist == 'Normal' && input.meth == 'Simulation'",
          numericInput("nclusterscpsdidnormal", "Number of Clusters", value = 6),
          numericInput(
            "nsubjectscpsdidnormal",
            "Number of Observations (per cluster)",
            value = 120
          ),
          numericInput(
            "nsimcpsdidnormal",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput("mucpsdidnormal", "Mean in arm 1", value = 1),
          numericInput("mu2cpsdidnormal", "Mean in arm 2", value = 0.48),
          numericInput(
            "sigma_sqcpsdidnormal",
            "Within-cluster variance (Arm 1)",
            step = 0.001,
            value = 1,
            min = 0
          ),
          numericInput(
            "sigma_b_sq01cpsdidnormal",
            "Pre-treatment between-cluster variance (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq02cpsdidnormal",
            "Pre-treatment between-cluster variance (Arm 2)",
            value = 0.1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq11cpsdidnormal",
            "Post-treatment between-cluster variance (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq12cpsdidnormal",
            "Post-treatment between-cluster variance (Arm 2)",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.did.binary input start
        conditionalPanel(
          "input.type == 'Difference-in-Difference' && input.dist == 'Binary' && input.meth == 'Analytic'",
          numericInput("nclusterscpadidbinary", "Number of Clusters", value = 33),
          numericInput(
            "nsubjectscpadidbinary",
            "Number of Observations (per cluster)",
            value = 50
          ),
          numericInput("dcpadidbinary", "Means difference", value = 0.1),
          numericInput("pcpadidbinary", "Mean post-test expected proportion", value = 0.5),
          numericInput(
            "ICCcpadidbinary",
            "Intracluster correlation coefficient (ICC)",
            value = 0.05,
            step = 0.01,
            min = 0,
            max = 1
          ),
          numericInput(
            "rho_ccpadidbinary",
            "Baseline and post-test cluster-level correlation",
            value = 0.3
          ),
          numericInput(
            "rho_scpadidbinary",
            "Baseline and post-test subject-level correlation",
            value = 0.7
          )
        ),
        
        # cps.did.binary input start
        conditionalPanel(
          "input.type == 'Difference-in-Difference' && input.dist == 'Binary' && input.meth == 'Simulation'",
          numericInput("nclusterscpsdidbinary", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpsdidbinary",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsimcpsdidbinary",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput(
            "p1cpsdidbinary",
            "Outcome proportion (Arm 1)",
            value = 0.2,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "p2cpsdidbinary",
            "Outcome proportion (Arm 2)",
            value = 0.45,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "sigma_b_sq01cpsdidbinary",
            "Pre-treatment between-cluster variance (Arm 1)",
            value = 1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq02cpsdidbinary",
            "Pre-treatment between-cluster variance (Arm 2)",
            value = 1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq11cpsdidbinary",
            "Post-treatment between-cluster variance (Arm 1)",
            value = 0,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq12cpsdidbinary",
            "Post-treatment between-cluster variance (Arm 2)",
            value = 0,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.did.count (no method)
        conditionalPanel(
          "input.type == 'Difference-in-Difference' && input.dist == 'Count' && input.meth == 'Analytic'",
          HTML("No method exists. Use the simulation option instead.")
        ),
        
        # cps.did.count input start
        conditionalPanel(
          "input.type == 'Difference-in-Difference' && input.dist == 'Count' && input.meth == 'Simulation'",
          numericInput("nclusterscpsdidcount", "Number of Clusters", value = 7),
          numericInput(
            "nsubjectscpsdidcount",
            "Number of Observations (per cluster)",
            value = 9
          ),
          numericInput(
            "nsimcpsdidcount",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput(
            "c1cpsdidcount",
            "Expected outcome count (Arm 1)",
            value = 5,
            step = 1,
            min = 0
          ),
          numericInput(
            "c2cpsdidcount",
            "Expected outcome count (Arm 2)",
            value = 3,
            step = 1,
            min = 0
          ),
          numericInput(
            "sigma_b_sq01cpsdidcount",
            "Pre-treatment between-cluster variance (Arm 1)",
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq02cpsdidcount",
            "Pre-treatment between-cluster variance (Arm 2)",
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq11cpsdidcount",
            "Post-treatment between-cluster variance (Arm 1)",
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq12cpsdidcount",
            "Post-treatment between-cluster variance (Arm 2)",
            value = 0.5,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.sw.normal input start
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Normal' && input.meth == 'Analytic'",
          numericInput("nclusterscpaswnormal", "Number of Clusters", value = 12),
          numericInput(
            "nsubjectscpaswnormal",
            "Number of Observations (per cluster)",
            value = 12
          ),
          numericInput(
            "ntimescpaswnormal",
            "Number of measurement time points",
            value = 3,
            min = 0,
            step = 1
          ),
          numericInput("dcpaswnormal", "Means difference", value = 1.5),
          numericInput(
            "ICCcpaswnormal",
            "Intracluster correlation coefficient (ICC)",
            value = 0.05,
            step = 0.01,
            min = 0,
            max = 1
          ),
          numericInput(
            "rho_ccpaswnormal",
            "Baseline and post-test cluster-level correlation",
            value = 0.8
          ),
          numericInput(
            "rho_scpaswnormal",
            "Baseline and post-test subject-level correlation",
            value = 0
          ),
          numericInput("vartcpaswnormal", "Total variation of the outcome", value = 16)
        ),
        
        # cps.sw.normal input start
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Normal' && input.meth == 'Simulation'",
          numericInput("nclusterscpsswnormal", "Number of Clusters", value = 12),
          numericInput(
            "nsubjectscpsswnormal",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsimcpsswnormal",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput("stepscpsswnormal", "Number of crossover steps", value = 3),
          numericInput("mucpsswnormal", "Mean in arm 1", value = 1.4),
          numericInput("mu2cpsswnormal", "Mean in arm 2", value = 3.2),
          numericInput(
            "sigma_sqcpsswnormal",
            "Within-cluster variance (Arm 1)",
            value = 0.01,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sqcpsswnormal",
            "Between-cluster variance (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.sw.binary input start
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Binary' && input.meth == 'Analytic'",
          numericInput("nclusterscpaswbinary", "Number of Clusters", value = 50),
          numericInput(
            "nsubjectscpaswbinary",
            "Number of Observations (per cluster)",
            value = 100
          ),
          numericInput("stepscpaswbinary", "Number of crossover steps", value = 2),
          numericInput("dcpaswbinary", "Means difference", value = -0.75),
          numericInput("mu0cpaswbinary", "Baseline (arm 1) effect", value = 0.2),
          numericInput("betacpaswbinary", "Treatment (arm 2) effect", value = 0.4),
          numericInput(
            "ICCcpaswbinary",
            "Intracluster correlation coefficient (ICC)",
            value = 0.01,
            step = 0.01,
            min = 0,
            max = 1
          )
        ),
        
        # cps.sw.binary input start
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Binary' && input.meth == 'Simulation'",
          numericInput("nclusterscpsswbinary", "Number of Clusters", value = 12),
          numericInput(
            "nsubjectscpsswbinary",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsimcpsswbinary",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput("stepscpsswbinary", "Number of crossover steps", value = 3),
          numericInput(
            "p1cpsswbinary",
            "Outcome proportion (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "p2cpsswbinary",
            "Outcome proportion (Arm 2)",
            value = 0.5,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "sigma_b_sqcpsswbinary",
            "Between-cluster variance (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        
        # cpa.sw.count input start
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Count' && input.meth == 'Analytic'",
          numericInput("nclusterscpaswcount", "Number of Clusters", value = 12),
          numericInput(
            "nsubjectscpaswcount",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput("stepscpaswcount", "Number of crossover steps", value = 3),
          numericInput(
            "ICCcpaswcount",
            "Intracluster correlation coefficient (ICC)",
            value = 0.05,
            step = 0.01,
            min = 0,
            max = 1
          ),
          numericInput(
            "lambda1cpaswcount",
            "Baseline rate for outcome of interest",
            value = 0.65
          ),
          numericInput("RRcpaswcount", "Intervention relative risk", value = 0.6)
        ),
        
        # cps.sw.count input start
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Count' && input.meth == 'Simulation'",
          numericInput("nclusterscpsswcount", "Number of Clusters", value = 12),
          numericInput(
            "nsubjectscpsswcount",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsimcpsswcount",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput("stepscpsswcount", "Number of crossover steps", value = 3),
          numericInput(
            "c1cpsswcount",
            "Expected outcome count (Arm 1)",
            value = 5,
            step = 1,
            min = 0
          ),
          numericInput(
            "c2cpsswcount",
            "Expected outcome count (Arm 2)",
            value = 7,
            step = 1,
            min = 0
          ),
          numericInput(
            "sigma_b_sqcpsswcount",
            "Between-cluster variance (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.irgtt.normal input start
        conditionalPanel(
          "input.type == 'Individually-Randomized Group' && input.dist == 'Normal' && input.meth == 'Analytic'",
          numericInput(
            "nclusterscpairgttnormal",
            "Number of clusters in the clustered arm",
            value = 8
          ),
          numericInput(
            "nsubjectscpairgttnormal",
            "Number of observations per cluster in the clustered arm",
            value = 15
          ),
          numericInput(
            "ncontrolscpairgttnormal",
            "Number of subjects in the unclustered arm",
            value = 40,
            step = 1,
            min = 0
          ),
          numericInput("dcpairgttnormal", "Means difference", value = 1.03),
          numericInput(
            "vareicpairgttnormal",
            "Intervention arm subject random error variance",
            value = 0.5,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "varrcpairgttnormal",
            "Control arm subject random error variance",
            value = 0.2,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "varucpairgttnormal",
            "Intervention arm cluster random effect variance",
            value = 1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cps.irgtt.normal input start
        conditionalPanel(
          "input.type == 'Individually-Randomized Group' && input.dist == 'Normal' && input.meth == 'Simulation'",
          numericInput(
            "nclusterscpsirgttnormal",
            "Number of Clusters (in the clustered arm)",
            value = 8
          ),
          numericInput(
            "nsubjects2cpsirgttnormal",
            "Number of Observations (per cluster)",
            value = 10
          ),
          numericInput(
            "nsubjectscpsirgttnormal",
            "Number of Observations (in unclustered arm)",
            value = 100
          ),
          numericInput(
            "nsimcpsirgttnormal",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput("mucpsirgttnormal", "Mean in arm 1", value = 1.1),
          numericInput("mu2cpsirgttnormal", "Mean in arm 2", value = 1.5),
          numericInput(
            "ICC2cpsirgttnormal",
            "Intracluster correlation coefficient (ICC)",
            value = NA,
            step = 0.01,
            min = 0,
            max = 1
          ),
          numericInput(
            "sigma_sqcpsirgttnormal",
            "Within-cluster variance (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_sq2cpsirgttnormal",
            "Within-cluster variance (Arm 2)",
            value = 0.2,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "sigma_b_sq2cpsirgttnormal",
            "Between-cluster variance (Arm 2)",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.irgtt.binary input start
        conditionalPanel(
          "input.type == 'Individually-Randomized Group' && input.dist == 'Binary' && input.meth == 'Analytic'",
          numericInput("nclusterscpairgttbinary", "Number of Clusters", value = 10),
          numericInput(
            "nsubjectscpairgttbinary",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "ncontrolscpairgttbinary",
            "Number of control subjects",
            value = 200,
            step = 1,
            min = 0
          ),
          numericInput(
            "p1cpairgttbinary",
            "Outcome proportion (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "p2cpairgttbinary",
            "Outcome proportion (Arm 2)",
            value = 0.2057,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "ICCcpairgttbinary",
            "Intracluster correlation coefficient (ICC)",
            value = 0.01,
            step = 0.01,
            min = 0,
            max = 1
          ),
          checkboxInput(
            "decreasecpairgttbinary",
            "Intervention probability < control probability",
            value = FALSE
          )
        ),
        
        # cps.irgtt.binary input start
        conditionalPanel(
          "input.type == 'Individually-Randomized Group' && input.dist == 'Binary' && input.meth == 'Simulation'",
          numericInput(
            "nclusterscpsirgttbinary",
            "Number of Clusters (in clustered arm)",
            value = 10
          ),
          numericInput(
            "nsubjectscpsirgttbinary",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsubjects2cpsirgttbinary",
            "Number of Observations (in unclustered arm)",
            value = 200
          ),
          numericInput(
            "nsimcpsirgttbinary",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput(
            "p1cpsirgttbinary",
            "Outcome proportion (Arm 1)",
            value = 0.1,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "p2cpsirgttbinary",
            "Outcome proportion (Arm 2)",
            value = 0.5,
            step = 0.001,
            min = 0,
            max = 1
          ),
          numericInput(
            "sigma_b_sq2cpsirgttbinary",
            "Between-cluster variance (Arm 2)",
            value = 0.1,
            step = 0.001,
            min = 0
          )
        ),
        
        # cpa.irgtt.count (no method)
        conditionalPanel(
          "input.type == 'Individually-Randomized Group' && input.dist == 'Count' && input.meth == 'Analytic'",
          HTML("No method exists. Use the simulation option instead.")
        ),
        
        # cps.irgtt.count input start
        conditionalPanel(
          "input.type == 'Individually-Randomized Group' && input.dist == 'Count' && input.meth == 'Simulation'",
          numericInput(
            "nclusterscpsirgttcount",
            "Number of Clusters (in clustered arm)",
            value = 10
          ),
          numericInput(
            "nsubjectscpsirgttcount",
            "Number of Observations (per cluster)",
            value = 20
          ),
          numericInput(
            "nsubjects2cpsirgttcount",
            "Number of Observations (in unclustered arm)",
            value = 200
          ),
          numericInput(
            "nsimcpsirgttcount",
            "Number of simulations",
            value = 100,
            max = 500000,
            min = 0
          ),
          numericInput(
            "sigma_b_sq2cpsirgttcount",
            "Between-cluster variance (Arm 2)",
            value = 0.1,
            step = 0.001,
            min = 0
          ),
          numericInput(
            "c1cpsirgttcount",
            "Expected outcome count (Arm 1)",
            value = 5,
            step = 1,
            min = 0
          ),
          numericInput(
            "c2cpsirgttcount",
            "Expected outcome count (Arm 2)",
            value = 7,
            step = 1,
            min = 0
          )
        )
      ),
      
      #end of values that can be reset with the restore defaults button
      
      actionButton(
        "button",
        "Estimate Power",
        icon = icon("arrow-circle-right"),
        width = '100%',
        style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
      ),
      actionButton('cancel', 'Cancel'),
      checkboxInput("more", "Show advanced options", value = FALSE),
      conditionalPanel(
        "input.more == true",
        bookmarkButton("Save App State"),
        sliderInput(
          "alpha",
          "Significance level (alpha)",
          value = 0.05,
          min = 0.01,
          max = 0.1,
          step = 0.02
        ),
        checkboxInput("verbose", "Show verbose results", value = FALSE),
        checkboxInput("debug", "Show debug/diagnostics tab (advanced)", value = FALSE)
      ),
      conditionalPanel(
        "input.more == true && input.meth == 'Simulation'",
        checkboxInput("timelimitOverride", "Allow unlimited calculation time", value = FALSE),
        checkboxInput("lowPowerOverride", "Allow completion when power is < 0.5", value = FALSE),
        checkboxInput(
          "poorFitOverride",
          "Allow completion when model fit is poor",
          value = FALSE
        ),
        textInput("optmethod", "Specify an optimization method", value = "NLOPT_LN_NELDERMEAD"),
        numericInput(
          "seed",
          "Set the seed (for repeatability)",
          value = NA,
          step = 1
        )
      ),
      conditionalPanel(
        "input.more == true",
        actionButton(
          "restoreDefault",
          "Restore default parameters",
          width = '100%',
          style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ),
        actionButton("reload", "Reset all", icon = icon("trash-alt"))
      )
    ),
    ########################
    # Tabs start
    ########################
    mainPanel(tabsetPanel(
      tabPanel(
        "Results",
        conditionalPanel(
          "input.dismissMsg == false && input.dismissMsg2 == false && input.more == false",
          wellPanel(
            HTML(
              "<p>Note: If the estimated calculation time is longer than 3 minutes,
            the process will not run unless you override the time limit
            under advanced options.</p>"
            ),
            checkboxInput("dismissMsg", "dismiss this message", value = FALSE)
          )
        ),
        conditionalPanel(
          "input.type == 'Stepped Wedge' && input.dist == 'Binary' &&
          input.meth == 'Analytic' && input.stepscpaswbinary > 3 &&
          input.dismissMsgCrossover == false",
          wellPanel(
            HTML(
              "<p>Note: Crossover steps > 3 will substantially increase
              calculation time. </p>"
            ),
            checkboxInput("dismissMsgCrossover", "dismiss this message", value = FALSE)
          )
        ),
        verbatimTextOutput("CRTpower", placeholder = TRUE),
        
        ####  DEBUG ACCESS PANEL START #####
        conditionalPanel(
          "input.debug == true",
          actionButton("browser", "browser"),
          tableOutput("show_inputs")
        )
        
        #### DEBUG ACCESS PANEL END #####
      ),
      tabPanel(
        "Graphs",
        conditionalPanel(
          "input.dismissMsg == false && input.dismissMsg2 == false && input.more == false",
          wellPanel(
            HTML(
              "<p>Note: If the estimated calculation time is longer than 3 minutes,
            the process will not run unless you override the time limit
            under advanced options.</p>"
            ),
            checkboxInput("dismissMsg2", "dismiss this message", value = FALSE)
          )
        ),
        selectInput("axisname",
                    "Y-axis name",
                    choices = c("nclusters", "nsubjects")),
        plotOutput("graphic", click = "click"),
        tableOutput("dp"),
        actionButton("cleargraph", "Clear Data", icon = icon("trash-alt")),
        tags$style(type = 'text/css', "button#cleargraph { margin-top: 100px; }")
      ),
      tabPanel(
        "Parameters",
        shinyjs::hidden(
          textInput("fxnName", "clusterPower function name", value = "cpa.normal")
        ),
        wellPanel(
          HTML(
            "<p>This table shows the values that the Shiny app passes
                   to the R functions.</p>
            <p>Note: for more advanced features, see the clusterPower R package.</p>"
          ),
          checkboxInput("showHelp", "Show help documentation", value = FALSE)
        ),
        fluidRow(column(width = 6, tableOutput("tracker")),
                 column(width = 6), 
                 conditionalPanel("input.showHelp == true", htmlOutput("helpdetails"))),
        downloadButton(
          "downloadData",
          "Download this table (.csv)",
          icon = icon("file-download"),
          style = "color: #fff; background-color: #337ab7; border-color: #2e6da4"
        ),
        actionButton("cleargraph2", "Clear Data", icon = icon("trash-alt")),
        tags$style(type = 'text/css', "button#cleargraph2 { margin-left: 250px; }")
      ),
      
      tabPanel(
        "Help",
        HTML(
          "<p>To use the calculator, select the trial type, outcome distribution, and calculation method.
        Then enter values for the quantities that appear below. When complete, select the ESTIMATE POWER button.</p>"
        ),
        HTML("<h3>Getting started</h3>"),
        HTML(
          "<p>The clusterPower package is intended to perform power calculations for many of the most common
             randomized controlled trial (RCT) designs. This app does not allow the user to access all of the
             functions available in the clusterPower R package, such as calculating the numbers of clusters or
             subjects needed to obtain a specific power, returning the raw simulated datasets, or viewing the
             results of each model fit. For these functions, use clusterPower with the R console rather than
             from within the applet.</p>
             <p>The first and most important step for using this app is to choose the appropriate experimental
             design and outcome distribution for your RCT. For more on this topic, consult the "
        ),
        tags$a(
          "clusterPower vignette.",
          href = get_vignette_link("clusterPower", package = "clusterPower"),
          target = "_blank"
        ),
        HTML(
          "To return to this page, click the back or reload button at the top of your browser window.</p>
          <h4>Choosing a distribution</h4>
          <p>After you have selected the RCT type using the pulldown menu, select the outcome distribution using
             the next pulldown menu. The options here include normal, binary, and count distributions. Use normal
             distribution when your measurement of interest is a numeric value. This can include measurements like
             descriptive variables such as weights, lab results, density, etc. Choose binary distribution if your
             outcome is a yes/no type of response metric, which would be found in studies with outcomes
             represented by exactly two choices (sometimes qualitative), such as survived/deceased, uninfected/infected,
             or participated/withdrew. Choose count when the outcome has more than two possible outcomes, such as
             uninfected/infected/recovered/died.</p>
             <h4>Choosing a method</h4>
        <p>The user can choose the calculation method using the 'Method' dropdown menu. The choices are analytical
        or simulation. Analytical methods have the advantage that calculations are sometimes faster than
             simulated methods, but many make assumptions about variance or balance in design that may sacrifice
             the accuracy of the power estimation. Simulated methods take longer to run but are more flexible because
             they make fewer assumptions. Furthermore, analytical methods don't exist for all RCT types, meaning that in
             those cases the simulation approach may be the user's only option. However, analytical and simulated
             power estimation will likely produce similar results.</p>
             <h4>Parameters</h4>
        <p>Depending on the user's choices as outlined in the previous sections, different parameter entry
             options will appear in the left-hand panel. All of these include the number of observations (or
             subjects, depending on design requirements), and the number of clusters in each arm. Other options
             include variables representing the expected outcomes for each arm, and those representing measures
             of variablity among and within clusters. For simulated methods, the user can also supply a number
             of simulations they would like to use for calculation.</p>
             <p>Here the user may want to consult the 'Parameters' tab option, which displays the verbatim
             parameter values that the app passes to the clusterPower backend as they are entered by the user.
             This table also shows the internal argument names for each parameter.</p>
             <h4>Advanced options</h4>
        <p>The checkbox near the bottom of the left-hand panel opens the Advanced Options for the app. For
             all analysis types, these options include options to bookmark the app state, restore the default
             parameters, or reset (reload) the app. Users can also adjust the significance cutoff value alpha
             using the slider. Typically this value is set to 0.05, which is the default for this app.</p>
             <p>For the simulation methods, there are 3-4 additional controls. These include:</p>
             <p>1) Time limit override: Simulation methods sometimes take a long time to complete. Each
             operation will produce a time estimate based on a few model fits. If the estimate is longer than
             2 minutes, the function will stop and return the estimated time to produce the desired fits.
             Unchecking this option allows the app to run indefinitely, so users can remove the time limit
             constraint if they choose.</p>
             <p>2) Low power override: The simulated methods also have a built-in option to stop fitting
             models if the calculated power is lower than 0.5. Generally, 0.8 is the ideal power target
             for RCT power estimation, so estimations that are very low trigger the alogrithm to stop
             fitting so that the user doesn't have to wait for the run to finish. However, the low power
             error can be overridden by selecting the low power override option.</p>
             <p>3) Poor fit override: When more than 25% of models fail to converge, the default app state
             will stop the calculation with an error, again to prevent the user from waiting a long time
             for uninformative results. Lack of convergence generally is an indication that the data is
             not a good fit for the models. This is ideally addressed by adjusting the model parameters.
             However, if the user wants to allow the procedure to run despite lack of convergence, the
             poor fit override option will override this error. Use this option with caution, as models
             lacking convergence may produce unreliable estimates.</p>
             <p>4) Some simulated methods allow the user to specify an optimizer, which can sometimes
             address convergence issues as an alternative to overriding the poor fit checks or excluding
             non-convergent models.</p>
          <h3>Results</h3>
          <p>After selecting the desired parameters, submit the job by clicking the Estimate Power button
          near the bottom of the screen. When complete, results will appear on the Results tab. Please
          keep in mind that calculations may take up to 2 minutes to complete, unless the user has chosen
          to override the time limit, in which case the wait time may be longer. Wait times vary depending
          on the CRT design and complexity of the resulting model, whether the method is analytic or
          simulation, and the amount of RAM available in the host computer. The Results tab shows the power
          calculation resulting from the most recent clusterPower run, although consecutive runs are logged
          unless the cached data is manually cleared, or the CRT type, method, or distribution is
          changed by the user.</p>
          <h3>Graphics</h3>
          <p> As mentioned in the previous section, consecutive runs are logged
          unless the cached data is manually cleared, or the CRT type, method, or distribution is
          changed by the user. On the Graphics tab, the user can graph any of the user-selected
          parameters against the resulting power estimate using the drop-down menu. Exact coordinates
          for each point can be obtained by clicking on the point of interest. If the user would like
          to clear the graph manually, the Clear Data button at the bottom of the panel will clear the
          Results and Parameters tabs to their original state.</p>
          <h3>Parameters</h3>
          <p>On the parameters tab, consecutive clusterPower runs are logged until the data is cleared
          or the user selects a different CRT type, method, or distribution. Parameters are shown
          according to their argument names when passed to the clusterPower function. To learn more
          about each parameter, select the 'Tell Me More About This' link near the top of the panel
          to open a pop-up window showing the documentation for the clusterPower function in use.</p>
          <h3>Note</h3>
          <p>App created by Alexandria Sakrejda, Jon Moyer, and Ken Kleinman; support from NIGMS grant R01GM121370.
          Please contact ken.kleinman@gmail.com with any feedback.</p>"
        )
      )
    )) # Tabs end
  )
)

######################################
#       SERVER
######################################

server <- function(input, output, session) {
  disable("cancel")
  out1 <- reactiveValues(power = NULL)
  logargs <- reactiveValues(tab = NULL)
  
  # Reload the app
  observeEvent(input$reload, {
    session$reload()
  })
  
  # Restore default values
  observeEvent(input$restoreDefault, {
    shinyjs::reset("allValues")
  })
  
  #change text input to numeric
  textToNum <- function(x) {
    result <- as.numeric(unlist(strsplit(x, split = ", ")))
    return(result)
  }
  
  #make some helpful fxns to extract arg names
  updateArgs <- function(fxnName) {
    argMatchResult <-
      c(
        clusterPower::argMatch(fxnName, justNames = TRUE),
        "lowPowerOverride",
        "poorFitOverride",
        "timelimitOverride",
        "power",
        "seed",
        "optmethod"
      )
    argNames <-
      c("nsubjects",
        "nclusters",
        "alpha",
        dplyr::intersect(argMatchResult,
                         names(formals(fxnName))))
    arghelper <- function(argname) {
      x <- paste0("input$", argname)
      #  x <- eval(parse(text = x))
      return(x)
    }
    holder <- list()
    for (i in 1:length(argNames)) {
      holder[[i]] <- arghelper(argNames[i])
    }
    names(holder) <- argNames
    return(holder)
  }
  
  printresult <- function(fxnName) {
    x <- rlang::exec(fxnName, !!!updateArgs(fxnName))
    return(x)
  }
  #end of fxns to extract argument names
  
  #which events to observe
  watchfor <- reactive({
    list(input$dist, input$meth, input$type, input$button)
  }) # end of which events to observe
  
  # update help documentation and params table when function is selected
  observe({
    if (input$type == 'Parallel' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.normal")
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.normal")
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.binary")
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.binary")
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.count")
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.count")
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.ma.normal")
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.ma.normal")
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.ma.binary")
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.ma.binary")
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.ma.count")
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.ma.count")
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.did.normal")
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.did.normal")
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.did.binary")
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.did.binary")
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.did.count")
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.did.count")
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.sw.normal")
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.sw.normal")
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.sw.binary")
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.sw.binary")
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.sw.count")
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.sw.count")
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.irgtt.normal")
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.irgtt.normal")
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.irgtt.binary")
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.irgtt.binary")
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      updateTextInput(session, "fxnName", value = "cpa.irgtt.count")
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      updateTextInput(session, "fxnName", value = "cps.irgtt.count")
    }
  }) # end update help documentation and params table when function is selected
  
  # call the clusterPower functions
  observeEvent(input$button, {
    disable("button")
    enable("cancel")
    
    prog <- Progress$new(session)
    prog$set(message = "Analysis in progress",
             detail = "This may take a while...",
             value = NULL)
    
    isolate({
      q <- reactiveValuesToList(input)
    })
    
    if (input$type == 'Parallel' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      answer <<- future({
        val <-
          cpa.normal(
            alpha = q$alpha,
            power = q$power,
            nclusters = q$nclusterscpanormal,
            nsubjects = q$nsubjectscpanormal,
            sigma_sq = q$sigma_sqcpanormal,
            sigma_b_sq = q$sigma_b_sqcpanormal,
            CV = q$CVcpanormal,
            d = q$dcpanormal,
            ICC = q$ICCcpanormal,
            vart = q$vartcpanormal
          )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.normal(
          nsim = q$nsimcpsnormal,
          nclusters = textToNum(q$nclusterscpsnormal),
          nsubjects = textToNum(q$nsubjectscpsnormal),
          mu = q$mucpsnormal,
          mu2 = q$mu2cpsnormal,
          ICC = q$ICCcpsnormal,
          sigma_sq = q$sigma_sqcpsnormal,
          sigma_b_sq = q$sigma_b_sqcpsnormal,
          ICC2 = q$ICC2cpsnormal,
          sigma_sq2 = q$sigma_sq2cpsnormal,
          sigma_b_sq2 = q$sigma_b_sq2cpsnormal,
          alpha = q$alpha,
          seed = q$seed,
          poorFitOverride = q$poorFitOverride,
          timelimitOverride = q$timelimitOverride,
          lowPowerOverride = q$lowPowerOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.binary(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpabinary,
          nsubjects = q$nsubjectscpabinary,
          CV = q$CVcpabinary,
          p1 = q$p1cpabinary,
          p2 = q$p2cpabinary,
          ICC = q$ICCcpabinary,
          pooled = q$pooledcpabinary,
          p1inc = q$p1inccpabinary,
          tdist = q$tdistcpabinary
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.binary(
          nsim = q$nsimcpsbinary,
          nsubjects = q$nsubjectscpsbinary,
          nclusters = q$nclusterscpsbinary,
          p1 = q$p1cpsbinary,
          p2 = q$p2cpsbinary,
          sigma_b_sq = q$sigma_b_sqcpsbinary,
          sigma_b_sq2 = q$sigma_b_sq2cpsbinary,
          alpha = q$alpha,
          seed = q$seed,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.count(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpacount,
          nsubjects = q$nsubjectscpacount,
          r1 = q$r1cpacount,
          r2 = q$r2cpacount,
          CVB = q$CVBcpacount,
          r1inc = q$r1inccpacount
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Parallel' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.count(
          nsim = q$nsimcpscount,
          nsubjects = q$nsubjectscpscount,
          nclusters = q$nclusterscpscount,
          c1 = q$c1cpscount,
          c2 = q$c2cpscount,
          sigma_b_sq = q$sigma_b_sqcpscount,
          sigma_b_sq2 = q$sigma_b_sq2cpscount,
          alpha = q$alpha,
          seed = q$seed,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.ma.normal(
          alpha = q$alpha,
          power = q$power,
          narms = q$narmscpamanormal,
          nclusters = q$nclusterscpamanormal,
          nsubjects = q$nsubjectscpamanormal,
          vara = q$varacpamanormal,
          varc = q$varccpamanormal,
          vare = q$varecpamanormal
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.ma.normal(
          nsim = q$nsimcpsmanormal,
          nsubjects = textToNum(q$nsubjectscpsmanormal),
          narms = q$narmscpsmanormal,
          nclusters = textToNum(q$nclusterscpsmanormal),
          means = textToNum(q$meanscpsmanormal),
          sigma_sq = textToNum(q$sigma_sqcpsmanormal),
          sigma_b_sq = textToNum(q$sigma_b_sqcpsmanormal),
          alpha = q$alpha,
          ICC = textToNum(q$ICCcpsmanormal),
          multi_p_method = q$multi_p_methodcpsmanormal,
          seed = q$seed,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          tdist = q$tdistcpsmanormal,
          optmethod = q$optmethod,
          timelimitOverride = q$timelimitOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.ma.binary()
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.ma.binary(
          nsim = q$nsimcpsmabinary,
          nsubjects = textToNum(q$nsubjectscpsmabinary),
          narms = q$narmscpsmabinary,
          nclusters = textToNum(q$nclusterscpsmabinary),
          probs = textToNum(q$probscpsmabinary),
          sigma_b_sq = textToNum(q$sigma_b_sqcpsmabinary),
          alpha = q$alpha,
          multi_p_method = q$multi_p_methodcpsmabinary,
          seed = q$seed,
          tdist = q$tdistcpsmabinary,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.ma.count()
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Multi-Arm' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.ma.count(
          nsim = q$nsimcpsmacount,
          nsubjects = textToNum(q$nsubjectscpsmacount),
          narms = q$narmscpsmacount,
          nclusters = textToNum(q$nclusterscpsmacount),
          counts = textToNum(q$countscpsmacount),
          sigma_b_sq = textToNum(q$sigma_b_sqcpsmacount),
          alpha = q$alpha,
          multi_p_method = q$multi_p_methodcpsmacount,
          seed = q$seed,
          tdist = q$tdistcpsmacount,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.did.normal(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpadidnormal,
          nsubjects = q$nsubjectscpadidnormal,
          d = q$dcpadidnormal,
          ICC = q$ICCcpadidnormal,
          rho_c = q$rho_ccpadidnormal,
          rho_s = q$rho_scpadidnormal,
          vart = q$vartcpadidnormal
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.did.normal(
          nsim = q$nsimcpsdidnormal,
          nsubjects = q$nsubjectscpsdidnormal,
          nclusters = q$nclusterscpsdidnormal,
          mu = q$mucpsdidnormal,
          mu2 = q$mu2cpsdidnormal,
          sigma_sq = q$sigma_sqcpsdidnormal,
          sigma_b_sq0 = c(
            q$sigma_b_sq01cpsdidnormal,
            q$sigma_b_sq02cpsdidnormal
          ),
          sigma_b_sq1 = c(
            q$sigma_b_sq11cpsdidnormal,
            q$sigma_b_sq12cpsdidnormal
          ),
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.did.binary(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpadidbinary,
          nsubjects = q$nsubjectscpadidbinary,
          p = q$pcpadidbinary,
          d = q$dcpadidbinary,
          ICC = q$ICCcpadidbinary,
          rho_c = q$rho_ccpadidbinary,
          rho_s = q$rho_scpadidbinary
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.did.binary(
          nsim = q$nsimcpsdidbinary,
          nsubjects = q$nsubjectscpsdidbinary,
          nclusters = q$nclusterscpsdidbinary,
          p1 = q$p1cpsdidbinary,
          p2 = q$p2cpsdidbinary,
          sigma_b_sq0 = c(
            q$sigma_b_sq01cpsdidbinary,
            q$sigma_b_sq02cpsdidbinary
          ),
          sigma_b_sq1 = c(
            q$sigma_b_sq11cpsdidbinary,
            q$sigma_b_sq12cpsdidbinary
          ),
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.did.count()
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Difference-in-Difference' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.did.count(
          nsim = q$nsimcpsdidcount,
          nsubjects = q$nsubjectscpsdidcount,
          nclusters = q$nclusterscpsdidcount,
          c1 = q$c1cpsdidcount,
          c2 = q$c2cpsdidcount,
          sigma_b_sq0 = c(
            q$sigma_b_sq01cpsdidcount,
            q$sigma_b_sq02cpsdidcount
          ),
          sigma_b_sq1 = c(
            q$sigma_b_sq11cpsdidcount,
            q$sigma_b_sq12cpsdidcount
          ),
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.sw.normal(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpaswnormal,
          nsubjects = q$nsubjectscpaswnormal,
          ntimes = q$ntimescpaswnormal,
          d = q$dcpaswnormal,
          ICC = q$ICCcpaswnormal,
          rho_c = q$rho_ccpaswnormal,
          rho_s = q$rho_scpaswnormal,
          vart = q$vartcpaswnormal
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.sw.normal(
          alpha = q$alpha,
          nsim = q$nsimcpsswnormal,
          nclusters = q$nclusterscpsswnormal,
          nsubjects = q$nsubjectscpsswnormal,
          steps = q$stepscpsswnormal,
          mu = q$mucpsswnormal,
          mu2 = q$mu2cpsswnormal,
          sigma_sq = q$sigma_sqcpsswnormal,
          sigma_b_sq = q$sigma_b_sqcpsswnormal,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.sw.binary(
          alpha = q$alpha,
          nclusters = q$nclusterscpaswbinary,
          steps = q$stepscpaswbinary,
          nsubjects = q$nsubjectscpaswbinary,
          d = q$dcpaswbinary,
          ICC = q$ICCcpaswbinary,
          beta = q$betacpaswbinary,
          mu0 = q$mu0cpaswbinary
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.sw.binary(
          nsim = q$nsimcpsswbinary,
          nsubjects = q$nsubjectscpsswbinary,
          nclusters = q$nclusterscpsswbinary,
          p1 = q$p1cpsswbinary,
          p2 = q$p2cpsswbinary,
          steps = q$stepscpsswbinary,
          sigma_b_sq = q$sigma_b_sqcpsswbinary,
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.sw.count(
          lambda1 = q$lambda1cpaswcount,
          RR = q$RRcpaswcount,
          nclusters = q$nclusterscpaswcount,
          steps = q$stepscpaswcount,
          nsubjects = q$nsubjectscpaswcount,
          ICC = q$ICCcpaswcount,
          alpha = q$alpha
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Stepped Wedge' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.sw.count(
          nsim = q$nsimcpsswcount,
          nsubjects = q$nsubjectscpsswcount,
          nclusters = q$nclusterscpsswcount,
          c1 = q$c1cpsswcount,
          c2 = q$c2cpsswcount,
          steps = q$stepscpsswcount,
          sigma_b_sq = q$sigma_b_sqcpsswcount,
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Normal' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.irgtt.normal(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpairgttnormal,
          nsubjects = q$nsubjectscpairgttnormal,
          ncontrols = q$ncontrolscpairgttnormal,
          d = q$dcpairgttnormal,
          varu = q$varucpairgttnormal,
          varei = q$vareicpairgttnormal,
          varr = q$varrcpairgttnormal
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Normal' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.irgtt.normal(
          nsim = q$nsimcpsirgttnormal,
          nsubjects = c(
            q$nsubjectscpsirgttnormal,
            q$nsubjects2cpsirgttnormal
          ),
          nclusters = q$nclusterscpsirgttnormal,
          mu = q$mucpsirgttnormal,
          mu2 = q$mu2cpsirgttnormal,
          sigma_sq = q$sigma_sqcpsirgttnormal,
          ICC2 = q$ICC2cpsirgttnormal,
          sigma_sq2 = q$sigma_sq2cpsirgttnormal,
          sigma_b_sq2 = q$sigma_b_sq2cpsirgttnormal,
          alpha = q$alpha,
          seed = q$seed,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Binary' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.irgtt.binary(
          alpha = q$alpha,
          power = q$power,
          nclusters = q$nclusterscpairgttbinary,
          nsubjects = q$nsubjectscpairgttbinary,
          ncontrols = q$ncontrolscpairgttbinary,
          ICC = q$ICCcpairgttbinary,
          p2 = q$p2cpairgttbinary,
          p1 = q$p1cpairgttbinary,
          decrease = q$decreasecpairgttbinary
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Binary' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.irgtt.binary(
          nsim = q$nsimcpsirgttbinary,
          nsubjects = c(
            q$nsubjectscpsirgttbinary,
            q$nsubjects2cpsirgttbinary
          ),
          nclusters = q$nclusterscpsirgttbinary,
          p1 = q$p1cpsirgttbinary,
          p2 = q$p2cpsirgttbinary,
          sigma_b_sq2 = q$sigma_b_sq2cpsirgttbinary,
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Count' && input$meth == 'Analytic') {
      answer <<- future({
        val <- cpa.irgtt.count()
        return(val)
      }, seed = TRUE)
    }
    if (input$type == 'Individually-Randomized Group' &&
        input$dist == 'Count' && input$meth == 'Simulation') {
      answer <<- future({
        val <- cps.irgtt.count(
          nsim = q$nsimcpsirgttcount,
          nsubjects = c(q$nsubjectscpsirgttcount, q$nsubjects2cpsirgttcount),
          nclusters = q$nclusterscpsirgttcount,
          c1 = q$c1cpsirgttcount,
          c2 = q$c2cpsirgttcount,
          sigma_b_sq2 = q$sigma_b_sq2cpsirgttcount,
          alpha = q$alpha,
          poorFitOverride = q$poorFitOverride,
          lowPowerOverride = q$lowPowerOverride,
          timelimitOverride = q$timelimitOverride,
          seed = q$seed
        )
        return(val)
      }, seed = TRUE)
    }
    
    then(
      answer,
      onFulfilled = function(value) {
        for (i in names(value)) {
          out1[[i]] <- value[[i]]
        }
        out1 <<- out1
      },
      onRejected = function(error) {
        out1$power <- paste0("ERROR: ", error$message)
      }
    )
    
    
    finally(answer, function() {
      prog$close()
      disable("cancel")
      enable("button")
    })
    
    return(NULL)
  }, ignoreInit = TRUE) # end call the clusterPower functions
  
  ##################
  
  # cancel button
  observeEvent(input$cancel, {
    async_pid <- answer$process$get_pid()
    print(paste("Killing PID:", async_pid))
    answer$process$kill()
    out1 <- NULL
    disable("cancel")
    enable("run1")
  }, ignoreInit = TRUE)
  
  #########################################
  #### DEBUG ACCESS PANEL #####
  #########################################
  
  AllInputs <- reactive({
    x <- reactiveValuesToList(input)
    holder <- NULL
    if (sum(grepl("click", names(x))) == 1) {
      x$click <- NULL
    }
    holder <- data.frame(
      names = names(x),
      values = unlist(x, use.names = FALSE),
      mode = unlist(lapply(x, mode))
    )
    dplyr::filter(holder, grepl(gsub("\\.", "", input$fxnName), names))
  })
  
  output$show_inputs <- renderTable({
    AllInputs()
  })
  
  observeEvent(input$browser, {
    browser()
  })
  
  ######################################### END DEBUG table
  
  #embedded documentation
  
  observe({
    helplink <<- sprintf(
      "http://127.0.0.1:%d/library/clusterPower/html/%s",
      tools::startDynamicHelp(NA),
      paste0(input$fxnName, ".html")
    )
  })
  
  output$helpdetails <- renderUI({
    tags$iframe(src = helplink,
                           height = 600,
                           width = 600)
  })
  
  #create the graphing table
  observeEvent(req(out1$power), {
    if (is.character(out1$power) == FALSE) {
      x <- reactiveValuesToList(input)
      holder <- NULL
      if (sum(grepl("click", names(x))) == 1) {
        x$click <- NULL
      }
      holder <- data.frame(
        argument = names(isolate(x)),
        values = unlist(isolate(x), use.names = FALSE)
      )
      specialnames <-
        dplyr::filter(holder, grepl(gsub("\\.", "", input$fxnName), argument))
      specialnames$argument <-
        gsub(gsub("\\.", "", input$fxnName),
             "",
             specialnames$argument)
      specialnames <- dplyr::arrange(specialnames, argument)
      if (x$meth == "Analytic") {
        tab <-
          rbind(specialnames,
                c("alpha", input$alpha),
                c("power", round(out1$power, 3)))
      }
      if (x$meth == "Simulation") {
        tab <-
          rbind(
            specialnames,
            c("alpha", input$alpha),
            c("upper CI", round(out1$power$Upper.95.CI, 3)),
            c("power", round(out1$power$Power, 3)),
            c("lower CI", round(out1$power$Lower.95.CI, 3))
          )
      }
      if (is.null(logargs$tab)) {
        logargs$tab <- tab
      } else {
        tab <- dplyr::select(tab, values)
        tab <- cbind.data.frame(logargs$tab, tab)
        logargs$tab <- data.frame(tab, check.names = TRUE)
      }
    } else {
      # if logargs$tab is an error, ignore it
      if (!is.null(logargs$tab)) {
        tab <- cbind.data.frame(logargs$tab)
        logargs$tab <- data.frame(tab, check.names = TRUE)
      }
    }
  })   # END create the graphing table
  
  #clear the data log under certain circumstances
  observeEvent(input$cleargraph, {
    logargs$tab <- NULL
    out1$power <- NULL
  })
  
  observeEvent(input$cleargraph2, {
    logargs$tab <- NULL
    out1$power <- NULL
  })
  
  observeEvent(input$fxnName, {
    logargs$tab <- NULL
    out1$power <- NULL
  })
  # END clear the data log under certain circumstances
  
  # START clear the output console when the estimate power button is clicked
  observeEvent(input$button, {
    out1$power <- "Calculating..."
  })
  # END clear the output console when the estimate power button is clicked
  
  # make the graph
  #update the axis choices
  observeEvent(input$fxnName, {
    x <- reactiveValuesToList(input)
    holder <- names(x)
    specialnames <-
      grep(gsub("\\.", "", input$fxnName), holder, value = TRUE)
    specialnames <-
      gsub(gsub("\\.", "", input$fxnName), "", specialnames)
    specialnames <-
      specialnames[grepl("nsim", specialnames) == FALSE]
    args_ <- c("alpha", specialnames)
    updateSelectInput(session, "axisname",
                      choices = args_)
  })
  
  plot_this <-
    eventReactive(list(input$axisname, req(logargs$tab)), {
      data <- data.frame(isolate(logargs$tab), check.names = TRUE)
      data$values <- as.numeric(data$values)
      data$argument <- as.factor(data$argument)
      var <- input$axisname
      data <-
        dplyr::filter(data, argument == !!var |
                        argument == "power")
      # first remember the names
      n <- data$argument
      # transpose all but the first column (name)
      data <- data.frame(t(data[, -1]))
      colnames(data) <- n
      data[, 1:2] <- apply(data[, 1:2], 2,
                           function(x)
                             as.numeric(as.character(x)))
      return(data)
    })
  
  dpfun <- function(x) {
    var <- input$axisname
    data <- plot_this()
    fun <- function(x) {
      x <- enquo(x)
      sol <-
        ggplot(data, aes(x = !!x, y = power)) +
        geom_point(aes(colour = "fff"), size = 2.5) +
        theme_minimal() + theme(legend.position = "none")
      return(sol)
    }
    power_plot <- suppressWarnings(fun(get(var)))
    if (nrow(data) > 1) {
      power_plot <-
        power_plot + geom_line(aes(colour = "fff"), size = 1.25) + xlab(var)
    } else {
      power_plot <- power_plot + xlab(var)
    }
    return(power_plot)
  }
  
  output$graphic <- renderPlot({
    dpfun()
  }, res = 96)
  
  output$dp <- renderTable({
    q <- plot_this()
    nearPoints(q, input$click, xvar = input$axisname)
  })
  
  # create reactive input data table
  output$tracker <-
    renderTable(logargs$tab)
  
  # Downloadable csv of reactive input data table
  output$downloadData <- downloadHandler(
    filename = function() {
      paste("clusterPower_", input$fxnName, ".csv", sep = "")
    },
    content = function(file) {
      write.csv(logargs$tab, file, row.names = FALSE)
    }
  )
  
  # present the output verbose/not verbose
  observeEvent(req(out1$power), {
    output$CRTpower <- renderPrint(if (input$verbose == FALSE)
      return(out1$power)
      else
        return(reactiveValuesToList(out1)))
  })
  
} #end of server fxn



# Run the application
shinyApp(ui = ui, server = server)
