clusterPower
============

[![](http://cranlogs.r-pkg.org/badges/clusterPower)](https://CRAN.R-project.org/package=clusterPower)
[![Build Status](https://travis-ci.org/Kenkleinman/clusterPower.svg?branch=master)](https://travis-ci.org/Kenkleinman/clusterPower)


clusterPower: power and sample size calculations for cluster-randomized trials, using both closed form and Monte Carlo methods

To get a version with a working shiny app, please download this file: https://github.com/Kenkleinman/clusterPower/releases/download/v1.0-beta/clusterPower_0.6.200.tar.gz and install it as a package in R.
