clusterPower
============

[![](http://cranlogs.r-pkg.org/badges/clusterPower)](https://CRAN.R-project.org/package=clusterPower)
[![Build Status](https://travis-ci.org/Kenkleinman/clusterPower.svg?branch=master)](https://travis-ci.org/Kenkleinman/clusterPower)


clusterPower: power and sample size calculations for cluster-randomized trials, using both closed form and Monte Carlo methods

